var typed=new typed(".text",{
	string:["Computer Science Student","Web Devloper","youTuber"],
	typeSpeed:100,
	backSpeed:100,
	backDelay:1000,
	loop:true
});	